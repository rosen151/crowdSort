package edu.msu.mi.turkmdr

class JavascriptController {

    def turk() {

    }
}
