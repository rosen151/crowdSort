package edu.msu.mi.turkmdr

class WorkflowRunController {

    def index() {}
}
