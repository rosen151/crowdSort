package edu.msu.mi.gwurk

class WorkflowRunController {



    def index() {}
}
